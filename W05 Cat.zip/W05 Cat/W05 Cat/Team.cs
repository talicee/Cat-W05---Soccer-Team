﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W05_Cat
{
    internal class Team
    {
        //variables atau attributes
        private string teamName;
        private string teamCountry;
        private string teamCity;
        private  List<Player> playerList;
        public string phoneNumber;
        private string privatePhone;

        //bedanya private = tdk bisa diakses di class lain, bisa dilakukan pengecekan di class agar ga dihack

        //Constructor
        public Team(string teamName , string teamCountry, string teamCity, List<Player> playerList)
        {
            this.teamName = teamName;
            this.teamCountry = teamCountry;    
            this.teamCity = teamCity;
            this.playerList = playerList;
        }

        //Getter = mengambil value dr atribut sebuah class
        public string getTeamName() { return teamName; }
        public string getTeamCountry() {  return teamCountry; }
        public string getTeamCity() {  return teamCity; }
        public List<Player> getPlayerList() {  return playerList; }


        //Setter = set value untuk attribut di dlm class
        public void setTeamName(string _teamName) { teamName = _teamName; }
        public void setTeamCountry(string _teamCountry) { teamCountry = _teamCountry; }
        public void setTeamCity(string _teamCity) { teamCity = _teamCity; }
        public void setTeamPlayer(List<Player> _playerList) {  playerList = _playerList; }
        public void setPrivatePhone(string _privatePhone)
        {
            if (_privatePhone.Contains("a"))
            {
                MessageBox.Show("Error");
            }
            else
            {
                privatePhone = _privatePhone;
            }
        }

        public void addPlayer(Player player)
        {
            bool kembar = false;
            foreach (Player p in playerList)
            {
                if (p.getPlayerNum() == player.getPlayerNum())
                {
                    kembar = true;
                    break;
                }
            }
            if (kembar)
            {
                MessageBox.Show("Ada player dengan nomor sama");
            }
            else
            {
                playerList.Add(player);
            }

        }
    }
}
