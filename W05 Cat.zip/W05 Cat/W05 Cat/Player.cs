﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W05_Cat
{
    internal class Player
    {
        //attribut
        private string playerNum;
        private string playerName;
        private string playerPos;

        //Constructor - dipanggil setiap class yang dibuat
        public Player(string _playerName, string _playerPos , string _playerNum)
        {
            playerName = _playerName;
            playerPos = _playerPos;
            playerNum = _playerNum;

        }

        //Getter
        public string getPlayerName() { return playerName; }
        public string getPlayerPos() { return playerPos; }
        public string getPlayerNum() { return playerNum; }

        //Setter
        public void setPlayerNum(string playerNum) { this.playerNum = playerNum; }
        public void setPlayerName(string playerName) {  this.playerName = playerName; }
        public void setPlayerPos (string playerPos) {  this.playerPos = playerPos; }
    }
}
