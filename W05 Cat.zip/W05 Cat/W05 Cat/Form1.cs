﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W05_Cat
{
    public partial class Form1 : Form
    {
        List<Team> teams;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            teams = new List<Team>();
            //team 1
            List<Player> players = new List<Player>
            {
                new Player("Edwin" , "GK" , "01"),
                new Player("Christian" , "DF" , "02"),
                new Player ("Keenan" , "FW" , "03")
            };
            teams.Add(new Team("UC Ceria", "Indonesia", "Surabaya" , players));

            //team 2
            players = new List<Player>
            {
                new Player("Edward" , "GK" , "05"),
                new Player("Jevon" , "DF" , "07"),
                new Player("Kevin" , "FW" , "15"),
                new Player("Steve" , "MF" , "20"),
            };
            teams.Add(new Team("AD Keren", "Indonesia", "Surabaya", players));

        }

        private void btn_Show_Click(object sender, EventArgs e)
        {
            
            foreach (Team t in teams)
            {
                t.addPlayer(new Player("Edwin", "GK", "01"));
                string output = t.getTeamName() + " is a " + t.getTeamCountry() + " team with " + t.getPlayerList().Count.ToString() + " players ";
                MessageBox.Show(output);

            }
        }
    }
}
